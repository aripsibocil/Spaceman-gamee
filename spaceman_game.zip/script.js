let balance = 100;
let multiplier = 1.00;
let gameInterval;
let exploded = false;

const balanceEl = document.getElementById('balance');
const multiplierEl = document.getElementById('multiplier');
const startBtn = document.getElementById('startBtn');
const cashoutBtn = document.getElementById('cashoutBtn');
const resultEl = document.getElementById('result');
const rocketEl = document.querySelector('.rocket');

startBtn.addEventListener('click', startGame);
cashoutBtn.addEventListener('click', cashOut);

function startGame() {
    multiplier = 1.00;
    exploded = false;
    resultEl.textContent = '';
    rocketEl.style.transform = 'translateY(0px)';
    startBtn.disabled = true;
    cashoutBtn.disabled = false;

    let explosionPoint = (Math.random() * 5 + 1).toFixed(2); // 1x - 6x
    gameInterval = setInterval(() => {
        multiplier += 0.01;
        multiplierEl.textContent = multiplier.toFixed(2);

        let moveY = -multiplier * 10;
        rocketEl.style.transform = `translateY(${moveY}px)`;

        if (multiplier >= explosionPoint) {
            explode();
        }
    }, 100);
}

function explode() {
    clearInterval(gameInterval);
    exploded = true;
    cashoutBtn.disabled = true;
    startBtn.disabled = false;
    resultEl.textContent = `💥 Rocket exploded at ${multiplier.toFixed(2)}x`;
}

function cashOut() {
    if (!exploded) {
        let winAmount = (10 * multiplier).toFixed(2); // taruhan default $10
        balance += parseFloat(winAmount);
        balanceEl.textContent = balance.toFixed(2);
        resultEl.textContent = `✅ You cashed out at ${multiplier.toFixed(2)}x and won $${winAmount}`;
        clearInterval(gameInterval);
        startBtn.disabled = false;
        cashoutBtn.disabled = true;
    }
}
